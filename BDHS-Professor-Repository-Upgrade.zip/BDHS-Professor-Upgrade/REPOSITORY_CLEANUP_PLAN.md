# Recommended Repository Cleanup

The current repository can remain functional as-is, but a cleaner scholarly structure will make it easier for supervisors, reviewers, collaborators, and PhD selection committees to evaluate the work.

## Recommended target structure

```text
BDHS-Unmet-Need-Analysis/
│
├── README.md
├── CITATION.cff
├── LICENSE
│
├── analysis/
│   ├── Analysis.do
│   ├── Spatials.do
│   └── Spatial_Figures.R
│
├── data-derived/
│   └── division_unmet_need_share.csv
│
├── outputs/
│   ├── figures/
│   │   └── Figure_1.pdf
│   ├── tables/
│   │   ├── Table_1.docx
│   │   └── Table_2.docx
│   └── flowchart/
│       └── Flowchart.tex
│
├── manuscript/
│   └── Contraception_BD.pdf
│
├── peer-review/
│   ├── round-1/
│   │   ├── Reviewer_1_Tracked_Comments.pdf
│   │   ├── Reviewer_2_Comments.pdf
│   │   └── Author_Response_Round_1.pdf
│   └── round-2/
│       ├── Reviewer_3_Comments.pdf
│       ├── Reviewer_4_Comments.docx
│       ├── Reviewer_5_Comments.docx
│       └── Author_Response_Round_2.pdf
│
└── docs/
    ├── REPRODUCIBILITY.md
    └── DATA_AVAILABILITY.md
```

## Recommended filename cleanup

| Current filename | Recommended filename |
|---|---|
| `Figure 1.pdf` | `Figure_1.pdf` |
| `Table 1.docx` | `Table_1.docx` |
| `Table 2.docx` | `Table_2.docx` |
| `RESPONSE LETTER.pdf` | `Author_Response_Round_1.pdf` |
| `Response Letter_V2.pdf` | `Author_Response_Round_2.pdf` |
| `Tracked_Changed_Comments_Reviewr_1.pdf` | `Reviewer_1_Tracked_Comments.pdf` |
| `reviewrs 2.pdf` | `Reviewer_2_Comments.pdf` |
| `Reviewr 3.pdf` | `Reviewer_3_Comments.pdf` |
| `Reviewr 4.docx` | `Reviewer_4_Comments.docx` |
| `Reviewr 5.docx` | `Reviewer_5_Comments.docx` |

## High-priority data-governance check

Before keeping `descriptive_data.dta` in a public repository, verify whether it contains DHS respondent-level microdata or recoverable micro-level records. The DHS Program prohibits redistribution of DHS micro-level datasets. If it does contain such data, remove it from the public repository and provide a reproducible data-preparation script instead.

Official DHS terms: https://dhsprogram.com/data/terms-of-use.cfm

## Why this structure is stronger

A senior academic opening the repository can immediately distinguish:

1. analytical code;
2. permitted derived data;
3. publication outputs;
4. manuscript/revision provenance; and
5. documentation for reproducibility and responsible data use.

That organization signals research maturity more effectively than keeping every artifact at repository root.
