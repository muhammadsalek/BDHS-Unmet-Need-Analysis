# Reproducibility Guide

## Computational workflow

The project uses Stata for the main complex-survey statistical analyses and spatial-data preparation, and R for spatial visualization.

### Core files

- `Analysis.do` — main statistical analysis workflow
- `Spatials.do` — spatial-data preparation
- `Spatial_Figures.R` — division-level spatial figures
- `division_unmet_need_share.csv` — derived division-level prevalence estimates
- `Flowchart.tex` — methodology-flowchart source

## Suggested software

- Stata 15 or later
- R 4.2 or later

## Reproduction sequence

1. Obtain authorized BDHS 2022 data directly from The DHS Program.
2. Place the required DHS data files in a local directory that is not tracked by Git.
3. Update file paths in `Analysis.do` for the local environment.
4. Run `Analysis.do`.
5. Run `Spatials.do`.
6. Run `Spatial_Figures.R` to regenerate the spatial outputs.
7. Compare regenerated outputs with the archived manuscript tables and figures.

## Reproducibility principle

The repository should make the transformation from authorized source data to published results inspectable while avoiding redistribution of restricted respondent-level data.
