# Data Availability and Responsible Use

## Primary data source

This study uses the Bangladesh Demographic and Health Survey (BDHS) 2022. Access to DHS microdata is administered by The DHS Program and requires user registration and approval for the intended research purpose.

## Redistribution

DHS micro-level datasets should not be redistributed through this repository. Researchers who wish to reproduce the analysis should request access directly from The DHS Program and then run the supplied analysis scripts using their authorized copy of the data.

## Repository data products

`division_unmet_need_share.csv` contains derived division-level estimates used for spatial visualization.

The repository currently also lists `descriptive_data.dta`. Before public distribution, the repository owner should verify that this file does not contain DHS micro-level respondent records or other information restricted by DHS data-use terms. If it does, it should be removed from the public repository.

## Official access resources

- DHS Program data portal: https://dhsprogram.com/data/
- Dataset Terms of Use: https://dhsprogram.com/data/terms-of-use.cfm
- Dataset access instructions: https://dhsprogram.com/data/Access-Instructions.cfm
